<?php
declare(strict_types=1);

function detect_separator(string $file): string {
    $fh = @fopen($file, 'r'); $first = ''; if ($fh) { $first = fgets($fh) ?: ''; fclose($fh); }
    $cands = [';', ',', '|', "\t"]; $best = ';'; $bestCount = -1;
    foreach ($cands as $sep) { $c = substr_count($first, $sep); if ($c > $bestCount) { $best = $sep; $bestCount = $c; } }
    return $best;
}

function read_csv_assoc(string $file): array {
    if (!is_file($file)) throw new RuntimeException("No existe el archivo ADP: $file");
    $sep = detect_separator($file);
    $fh = fopen($file, 'r'); if(!$fh) throw new RuntimeException('No se pudo abrir el archivo ADP.');
    $headers_raw = fgetcsv($fh, 0, $sep); if (!$headers_raw) throw new RuntimeException('No se detectaron columnas en ADP.');
    $headers = []; foreach ($headers_raw as $h) { $headers[] = trim(utf8_encode((string)$h)); }
    $rows = [];
    while (($row = fgetcsv($fh, 0, $sep)) !== false) {
        if (count($row) === 1 && trim((string)$row[0]) === '') continue;
        $assoc = [];
        foreach ($headers as $i => $col) {
            if ($col === '') continue;
            $val = isset($row[$i]) ? (string)$row[$i] : '';
            $assoc[$col] = trim(utf8_encode($val));
        }
        if (implode('', $assoc) !== '') $rows[] = $assoc;
    }
    fclose($fh);
    return [$headers, $rows, $sep];
}

function pick(array $row, array $cands): string { foreach ($cands as $c) { if (array_key_exists($c, $row) && $row[$c] !== '') return $row[$c]; } return ''; }

/**
 * Cálculo ESTRICTO: solo desde el archivo ADP.
 * Intenta columnas: Otorgados/Grant, Tomados/Dias y/o Saldo por año.
 */
function compute_vacation_from_file(array $adpRows, string $employeeCode): array {
    $employeeCode = trim($employeeCode);
    $rows = [];
    foreach ($adpRows as $r) {
        $code = trim(pick($r, ['Código del Empleado', 'Codigo del Empleado', 'Codigo Empleado', 'Rut', 'RUT']));
        if ($code !== '' && strcasecmp($code, $employeeCode) === 0) $rows[] = $r;
    }
    if (count($rows) === 0) {
        return ['found'=>false,'byYear'=>[],'totalBalance'=>null,'columnsFound'=>['granted'=>false,'taken'=>false,'balance'=>false]];
    }

    $perYear = []; $flags = ['granted'=>false,'taken'=>false,'balance'=>false];

    foreach ($rows as $r) {
        $periodosStr = pick($r, ['Periodo', 'Periodos', 'Períodos', 'Anio', 'Año']);
        preg_match_all('/\b(19|20)\d{2}\b/', $periodosStr, $m);
        $year = isset($m[0][0]) ? (int)$m[0][0] : (int)date('Y');
        if (!isset($perYear[$year])) $perYear[$year] = ['granted'=>null,'taken'=>null,'balance'=>null];

        $gRaw = pick($r, ['Otorgados','Grant','Otorgado','Asignados']);
        if ($gRaw !== '') { $g = (float)str_replace(',', '.', $gRaw); $perYear[$year]['granted'] = ($perYear[$year]['granted'] ?? 0) + $g; $flags['granted']=true; }

        $tRaw = pick($r, ['Tomados','Consumidos','Usados','Días','Dias']);
        if ($tRaw !== '') { $t = (float)str_replace(',', '.', $tRaw); $perYear[$year]['taken']   = ($perYear[$year]['taken'] ?? 0) + $t; $flags['taken']=true; }

        $bRaw = pick($r, ['Saldo','Balance','Disponible']);
        if ($bRaw !== '') { $b = (float)str_replace(',', '.', $bRaw); $perYear[$year]['balance'] = ($perYear[$year]['balance'] ?? 0) + $b; $flags['balance']=true; }
    }

    ksort($perYear);
    $byYear = []; $total = 0.0; $hasTotal = false;
    foreach ($perYear as $y=>$v) {
        $granted = is_null($v['granted']) ? null : (float)$v['granted'];
        $taken   = is_null($v['taken'])   ? null : (float)$v['taken'];
        $balance = null;
        if (!is_null($v['balance'])) { $balance = (float)$v['balance']; $hasTotal=true; $total += $balance; }
        elseif (!is_null($granted) && !is_null($taken)) { $balance = $granted - $taken; $hasTotal=true; $total += $balance; }
        $byYear[] = ['year'=>$y,'granted'=>$granted,'taken'=>$taken,'balance'=>$balance];
    }

    return ['found'=>true,'byYear'=>$byYear,'totalBalance'=>$hasTotal ? $total : null,'columnsFound'=>$flags];
}

function decision_from_file_balance(array $balance, float $requestedDays): array {
    if (!$balance['found']) return ['ok'=>false,'reason'=>'not_found','message'=>'Empleado no existe en ADP','requested'=>$requestedDays];
    if ($balance['totalBalance'] === null) return ['ok'=>false,'reason'=>'insufficient_data','message'=>'Faltan columnas (Saldo o Otorgados+Tomados)','requested'=>$requestedDays];
    $before = (float)$balance['totalBalance']; $ok = $before >= $requestedDays;
    return ['ok'=>$ok,'reason'=>$ok?'enough':'not_enough','balanceBefore'=>$before,'requested'=>$requestedDays,'balanceAfter'=>$before-$requestedDays];
}
